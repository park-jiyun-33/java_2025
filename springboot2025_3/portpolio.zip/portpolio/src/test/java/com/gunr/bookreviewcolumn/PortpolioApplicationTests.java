package com.gunr.bookreviewcolumn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortpolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
